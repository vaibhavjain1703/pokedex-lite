import React, { useEffect, useState, useCallback } from 'react'
import { fetchPokemonList, fetchPokemonDetail, fetchTypes } from './services/api'
import PokemonCard from './components/PokemonCard'
import PokemonModal from './components/PokemonModal'
import Pagination from './components/Pagination'
import SearchFilter from './components/SearchFilter'
import TypeFilter from './components/TypeFilter'
import useFavorites from './hooks/useFavorites'

export default function App() {
  const PAGE_LIMIT = 24
  const [offset, setOffset] = useState(0)
  const [pokemons, setPokemons] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [selected, setSelected] = useState(null)
  const [search, setSearch] = useState('')
  const [types, setTypes] = useState([])
  const [selectedTypes, setSelectedTypes] = useState([])
  const [total, setTotal] = useState(0)
  const { favorites, toggleFavorite } = useFavorites()

  const loadTypes = useCallback(async () => {
    try {
      const t = await fetchTypes()
      setTypes(t)
    } catch (err) {
      console.error(err)
    }
  }, [])

  useEffect(() => { loadTypes() }, [loadTypes])

  const loadPage = useCallback(async (off = 0) => {
    setLoading(true)
    setError(null)
    try {
      const data = await fetchPokemonList({ offset: off, limit: PAGE_LIMIT })
      setTotal(data.count)
      // We will map results to include image by fetching detail for each entry in parallel with a limit.
      const detailPromises = data.results.map(r => fetchPokemonDetail(r.name).catch(e => null))
      const details = await Promise.all(detailPromises)
      const merged = data.results.map((r, i) => ({
        name: r.name,
        url: r.url,
        detail: details[i]
      }))
      setPokemons(merged)
      setOffset(off)
    } catch (err) {
      console.error(err)
      setError('Failed to load Pokémon. Check your network.')
    } finally {
      setLoading(false)
    }
  }, [])

  useEffect(() => {
    loadPage(0)
  }, [loadPage])

  // Derived list after search and type filter
  const displayed = pokemons.filter(p => {
    if (search && !p.name.includes(search.toLowerCase())) return false
    if (selectedTypes.length > 0) {
      const det = p.detail
      if (!det) return false
      const pokemonTypes = det.types.map(t => t.type.name)
      // must include all selected types
      return selectedTypes.every(st => pokemonTypes.includes(st))
    }
    return true
  })

  return (
    <div className="app">
      <header className="header">
        <h1>Pokedex Lite</h1>
      </header>

      <main className="container">
        <div className="controls">
          <SearchFilter value={search} onChange={setSearch} />
          <TypeFilter types={types} selected={selectedTypes} onChange={setSelectedTypes} />
        </div>

        {loading && <div className="message">Loading Pokémon...</div>}
        {error && <div className="message error">{error}</div>}

        <section className="grid">
          {displayed.map(p => (
            <PokemonCard
              key={p.name}
              pokemon={p}
              onOpen={() => setSelected(p)}
              isFavorite={favorites.includes(p.name)}
              onToggleFavorite={() => toggleFavorite(p.name)}
            />
          ))}
        </section>

        <Pagination
          offset={offset}
          limit={PAGE_LIMIT}
          total={total}
          onPageChange={(newOffset) => loadPage(newOffset)}
        />

        {selected && (
          <PokemonModal
            pokemon={selected}
            onClose={() => setSelected(null)}
            isFavorite={favorites.includes(selected.name)}
            onToggleFavorite={() => toggleFavorite(selected.name)}
          />
        )}

      </main>

      <footer className="footer">
        <div>Favorites: {favorites.length}</div>
      </footer>
    </div>
  )
}

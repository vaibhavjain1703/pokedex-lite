import { useEffect, useState } from 'react'

const KEY = 'pokedex-lite:favorites'

export default function useFavorites() {
  const [favorites, setFavorites] = useState([])

  useEffect(() => {
    try {
      const raw = localStorage.getItem(KEY)
      if (raw) setFavorites(JSON.parse(raw))
    } catch (e) {
      console.warn('Could not load favorites', e)
    }
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(favorites))
    } catch (e) {
      console.warn('Could not save favorites', e)
    }
  }, [favorites])

  const toggleFavorite = (name) => {
    setFavorites(prev => prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name])
  }

  return { favorites, toggleFavorite }
}

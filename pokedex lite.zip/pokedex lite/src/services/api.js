const BASE = 'https://pokeapi.co/api/v2'

export async function fetchPokemonList({ offset = 0, limit = 24 } = {}) {
  const res = await fetch(`${BASE}/pokemon?offset=${offset}&limit=${limit}`)
  if (!res.ok) throw new Error('List fetch failed')
  return res.json()
}

export async function fetchPokemonDetail(nameOrUrl) {
  const url = typeof nameOrUrl === 'string' && nameOrUrl.startsWith('http') ? nameOrUrl : `${BASE}/pokemon/${nameOrUrl}`
  const res = await fetch(url)
  if (!res.ok) throw new Error('Detail fetch failed')
  return res.json()
}

export async function fetchTypes() {
  const res = await fetch(`${BASE}/type`)
  if (!res.ok) throw new Error('Types fetch failed')
  const data = await res.json()
  // return array of type names (exclude 'unknown' and 'shadow' if present)
  return data.results.map(r => r.name).filter(n => n !== 'unknown' && n !== 'shadow')
}

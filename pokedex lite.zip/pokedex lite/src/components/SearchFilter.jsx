import React from 'react'

export default function SearchFilter({ value, onChange }) {
  return (
    <input
      className="search"
      placeholder="Search Pokémon by name..."
      value={value}
      onChange={e => onChange(e.target.value)}
      aria-label="search"
    />
  )
}

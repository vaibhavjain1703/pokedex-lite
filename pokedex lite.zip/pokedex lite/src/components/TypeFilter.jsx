import React from 'react'

export default function TypeFilter({ types = [], selected = [], onChange }) {
  const toggle = (name) => {
    if (selected.includes(name)) onChange(selected.filter(s => s !== name))
    else onChange([...selected, name])
  }

  return (
    <div className="type-filter">
      {types.map(t => (
        <button key={t} className={`type-btn ${selected.includes(t) ? 'on' : ''}`} onClick={() => toggle(t)}>{t}</button>
      ))}
    </div>
  )
}

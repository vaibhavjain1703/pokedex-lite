import React from 'react'

export default function PokemonCard({ pokemon, onOpen, isFavorite, onToggleFavorite }) {
  const detail = pokemon.detail
  const image = detail?.sprites?.other?.['official-artwork']?.front_default || detail?.sprites?.front_default || ''
  return (
    <article className="card" onClick={onOpen} role="button" tabIndex={0}>
      <div className="card-top">
        {image ? <img src={image} alt={pokemon.name} /> : <div className="placeholder">No image</div>}
        <button className={`fav ${isFavorite ? 'on' : ''}`} onClick={(e) => { e.stopPropagation(); onToggleFavorite() }} aria-label="toggle favorite">★</button>
      </div>
      <div className="card-body">
        <h3>{pokemon.name}</h3>
        {detail && (
          <div className="types">
            {detail.types.map(t => <span key={t.type.name} className={`type ${t.type.name}`}>{t.type.name}</span>)}
          </div>
        )}
      </div>
    </article>
  )
}

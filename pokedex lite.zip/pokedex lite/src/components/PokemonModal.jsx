import React, { useEffect, useState } from 'react'
import { fetchPokemonDetail } from '../services/api'

export default function PokemonModal({ pokemon, onClose, isFavorite, onToggleFavorite }) {
  const [detail, setDetail] = useState(pokemon.detail)
  const [loading, setLoading] = useState(!pokemon.detail)

  useEffect(() => {
    let mounted = true
    if (!detail) {
      setLoading(true)
      fetchPokemonDetail(pokemon.name).then(d => { if (mounted) setDetail(d) }).catch(()=>{}).finally(()=>{ if (mounted) setLoading(false) })
    }
    return () => { mounted = false }
  }, [pokemon, detail])

  if (!detail && loading) return null

  const image = detail?.sprites?.other?.['official-artwork']?.front_default || detail?.sprites?.front_default

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <header className="modal-header">
          <h2>{detail.name}</h2>
          <button onClick={onClose}>Close</button>
        </header>
        <div className="modal-body">
          <div className="modal-left">
            {image ? <img src={image} alt={detail.name} /> : <div className="placeholder">No image</div>}
            <button className={`fav big ${isFavorite ? 'on' : ''}`} onClick={onToggleFavorite}>★</button>
          </div>
          <div className="modal-right">
            <h3>Stats</h3>
            <ul>
              {detail.stats.map(s => (
                <li key={s.stat.name}>{s.stat.name}: {s.base_stat}</li>
              ))}
            </ul>
            <h3>Abilities</h3>
            <ul>
              {detail.abilities.map(a => <li key={a.ability.name}>{a.ability.name}</li>)}
            </ul>
            <h3>Moves (sample)</h3>
            <div className="moves">
              {detail.moves.slice(0,6).map(m => <span key={m.move.name} className="chip">{m.move.name}</span>)}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

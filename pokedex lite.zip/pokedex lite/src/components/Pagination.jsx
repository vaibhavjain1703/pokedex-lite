import React from 'react'

export default function Pagination({ offset, limit, total, onPageChange }) {
  const canPrev = offset > 0
  const canNext = offset + limit < total

  return (
    <div className="pagination">
      <button onClick={() => onPageChange(Math.max(0, offset - limit))} disabled={!canPrev}>Previous</button>
      <div>Showing {offset + 1} - {Math.min(offset + limit, total)} of {total}</div>
      <button onClick={() => onPageChange(offset + limit)} disabled={!canNext}>Next</button>
    </div>
  )
}
